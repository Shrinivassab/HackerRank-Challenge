/* Welcome to Java 
Welcome to the world of Java! This is your first step to learn this wonderful language. Print "Hello World." and "Hello Java." in the console to complete this challenge. 

(You should write a main function inside a public class called Solution; otherwise, your code will not compile.)

Input Format

There is no input for this problem.

Output Format

Output the two sentences in separate lines. See sample output.

Sample Input

There is no input for this problem.
*/

public class WelcomeToJava
{
    static public void main(String[] args){
        System.out.println("Hello World.");
        System.out.println("Hello Java.");
    }
}